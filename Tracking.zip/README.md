<p align="left">
<a href="#"><img title="Made in INDIA" src="https://img.shields.io/badge/MADE%20IN%20-INDIA-orange?colorA=%23ff0000&colorB=%23017e40&style=for-the-badge"></a>
</p>
<p align="center">
<a href="#"><img title="Host" src="https://raw.githubusercontent.com/htr-tech/release-download/master/images/banner/trackip.png"></a>
</p>
<p align="center">
<a href="https://github.com/htr-tech"><img title="Author" src="https://img.shields.io/badge/Author%20-Sillytuktuk2020-green.svg?style=for-the-badge&logo=github"></a>
<a href="#"><img title="Open Source" src="https://img.shields.io/badge/Open%20-Source%20%F0%9F%98%8E-yellowgreen?style=for-the-badge"></a>
</p>
<p align="center">
<a href="#"><img title="Version" src="https://img.shields.io/badge/Version%20-0.2-yellow.svg?style=flat-square"></a>
</p>

## Installation :

* `apt update`
* `apt install git curl -y`
* `git clone https://github.com/sillytuktuk2020/Track_iP.git `
* `cd Track_iP`

#### > Run : `bash  Track_iP`

## Single Command :
```
apt update ; apt install git curl -y ; git clone https://github.com/sillytuktuk2020/Track_iP ; cd Track_iP ; bash Track_iP
```
<br>
<p align="center">
<img src="https://raw.githubusercontent.com/htr-tech/release-download/master/images/trackip.png"/>

### <<< If you copy , Then Give me The Credits >>>

## Find Me on :
[![Github](https://img.shields.io/badge/Github-Sillytuktuk2020-green?style=for-the-badge&logo=github)](https://github.com/sillytuktuk2020)
[![Instagram](https://img.shields.io/badge/IG-decent__deep__raadhe-yellowgreen?style=for-the-badge&logo=instagram)](https://www.instagram.com/decent_deep_raadhe)
[![Messenger](https://img.shields.io/badge/Chat-Messenger-blue?style=for-the-badge&logo=messenger)
